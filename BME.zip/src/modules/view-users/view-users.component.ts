import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/services/data.service';

@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.scss']
})
export class ViewUsersComponent implements OnInit {
  usersArr:any;

  constructor(private service:DataService) { }

  ngOnInit(): void {
    this.AllUsersData();
  }

  public AllUsersData(){
    this.service.GetAllUsers().subscribe(
    (response:any)=>{
      console.log(response);
      this.usersArr=response;
    },
    (error:any)=>{
      console.log(error);
    }
    )
}

}
