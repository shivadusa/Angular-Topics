import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/services/data.service';

@Component({
  selector: 'app-admin-profile',
  templateUrl: './admin-profile.component.html',
  styleUrls: ['./admin-profile.component.scss']
})
export class AdminProfileComponent implements OnInit {
  AdminArr:any[]=[];
  AdminName:any;
  AdminMobileNumber:any

  constructor(private service:DataService) { }

  ngOnInit(): void {
    this.GetAdmin();
  }

  public GetAdmin(){
    this.service.GetAdminById(4).subscribe(
     (response:any)=>{
       console.log(response);
       this.AdminArr.push(response);
     },
     (error:any)=>{
       console.log(error);
     }
    )
  }

  public EditData(){
    this.AdminName='';
  }

}
