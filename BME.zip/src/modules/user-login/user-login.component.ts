import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from 'src/services/data.service';


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.scss']
})
export class UserLoginComponent implements OnInit {
  LoginForm:any=FormGroup;
  errorMessage:string='';
  //Payment Task Purpose
 

  constructor(private fb:FormBuilder,private service:DataService,private router:Router) { }

  ngOnInit(): void {
    this.CreateLogin();
  }

 
  //Reactive Form data
  public CreateLogin(){
    this.LoginForm=this.fb.group({
      email:['',[Validators.required]],
      password:['',[Validators.required]],
    })
    }
   //Service Data
 

   //Admin and User Data
   public UserAndAdminData(){
     if(this.LoginForm.value.email="admin@gmail.com",this.LoginForm.value.password="Admin@123"){
       this.GetAdmin();
     }
     else{
       this.service.GetUserLogin(this.LoginForm.value.email,this.LoginForm.value.password).subscribe(
         (response:any)=>{
           if(response==null){
             this.errorMessage="Login Failed"
           }
           else{
             this.errorMessage="Login success";
             this.router.navigate(['user-home']);
           }
         },
         (error:any)=>{
           console.log(error);
         }
       )
     }
   }
   
   //Admin service Data
   public GetAdmin(){
     this.service.AdminData(this.LoginForm.value.email,this.LoginForm.value.password).subscribe(
       (response:any)=>{
         if(response==null){
           this.errorMessage="Login falied";
         }
         else{
           this.errorMessage="Login success";
           this.router.navigate(['user-admin']);
         }
       },
       (error:any)=>{
        console.log(error);
       }
     )
      }


  //  //SuperAdmin Service Data
  //  public GetSuperAdmin(){
  //    this.service.SuperAdminData(this.LoginForm.value.email,this.LoginForm.value.password).subscribe(
  //      (response:any)=>{
  //        if(response==null){
  //          this.errorMessage="Login Failed";
  //        }
  //        else{
  //          this.errorMessage="Login Success";
  //        }
  //      },
  //      (error:any)=>{
  //        console.log(error);
  //      }
  //    )
  //  }

  // }

  
    }

  


