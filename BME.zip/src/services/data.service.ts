import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class DataService {
  baseUrl:string="https://localhost:44386/";

  constructor(private http:HttpClient) { }

  //User Login Service data
  public GetUserLogin(email:string,password:string){
    return this.http.get(this.baseUrl+`api/Bme/user/Login/${email}/${password}`);
  }
  //Admin Login Service Data
  public AdminData(email:string,password:string){
    return this.http.get(this.baseUrl+`api/Bme/admin/Login/${email}/${password}`)
  }
  //SuperAdmin Login Service Data
  public SuperAdminData(email:string,password:string){
    return this.http.get(this.baseUrl+`api/Bme/Superadmin/Login/${email}/${password}`)
  }
  //GetAllUsers Data
  public GetAllUsers(){
    return this.http.get(this.baseUrl+'api/Bme/User/GetAllUsersData')
  }
  //GetAdmin Data ById
  public GetAdminById(adminid:number){
    return this.http.get(this.baseUrl+`api/Bme/admin/Get/${adminid}`)
  }
  //AdminDetails Update Data
  public UpdateAdmin(admin:any){
    return this.http.post(this.baseUrl+``)
  }

}
