import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path:'user-login',loadChildren:()=>import('./../modules/user-login/user-login.module').then(m=>m.UserLoginModule)},
  {path:'user-admin',loadChildren:()=>import('./../modules/user-admin/user-admin.module').then(m=>m.UserAdminModule)},
  {path:'user-home',loadChildren:()=>import('./../modules/user-home/user-home.module').then(m=>m.UserHomeModule)},
  {path:'view-users',loadChildren:()=>import('./../modules/view-users/view-users.module').then(m=>m.ViewUsersModule)},
  {path:'Admin-Profile',loadChildren:()=>import('./../modules/admin-profile/admin-profile.module').then(m=>m.AdminProfileModule)}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
