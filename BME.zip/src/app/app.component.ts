import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'BookMyEvent';
  SenderAmount:number=1000;
  BenficiaryAmount:number=0;
  EnteredAmount:number=0;
  public Payment(){
    this.SenderAmount=this.SenderAmount-this.EnteredAmount;
    this.BenficiaryAmount=this.BenficiaryAmount+this.EnteredAmount;
  }
}
